create view d_imovel_contrato
            (status_contrato, id_uo_beneficiada, numero_contrato, id_tipo_contrato, data_inicio_vigencia,
             data_fim_vigencia, valor_contrato, valor_original, id_indice_reajuste, id_adverso_principal, id_contrato,
             garantias, objetos, id_imovel, id_usuario_cadastro, ultima_modificacao, data_cadastro, id_imovel_contrato)
as
SELECT CASE
           WHEN co.fase_contrato::text = 'T'::text THEN 'T'::text
           WHEN co.cancelado = 'T'::bpchar THEN 'I'::text
           WHEN co.fase_contrato::text = 'R'::text THEN 'R'::text
           WHEN co.fase_contrato::text = 'C'::text THEN 'CO'::text
           WHEN co.fim_vigencia_indeterminado = 'T'::bpchar THEN 'A'::text
           WHEN co.data_fim_vigencia IS NULL THEN 'A'::text
           WHEN date_part('day'::text, co.data_fim_vigencia::timestamp with time zone - CURRENT_TIMESTAMP) >=
                0::double precision THEN 'A'::text
           ELSE 'V'::text
           END                                                                    AS status_contrato,
       co.id_uo_beneficiada,
       co.id_contrato                                                             AS numero_contrato,
       co.id_tipo_contrato,
       co.data_inicio_vigencia,
       co.data_fim_vigencia,
       co.valor_contrato,
       co.valor_original,
       co.id_indice_reajuste,
       co.id_fornecedor                                                           AS id_adverso_principal,
       co.id_contrato,
       array_to_string(ARRAY(SELECT ga_1.garantia
                             FROM d_contrato_garantia ga_1
                             WHERE ga_1.id_contrato = co.id_contrato), ','::text) AS garantias,
       array_to_string(ARRAY(SELECT lto.tipo_objeto_contrato
                             FROM d_contrato_objeto ob
                                      JOIN lt_tipo_objeto_contrato lto
                                           ON ob.id_tipo_objeto_contrato = lto.id_tipo_objeto_contrato
                             WHERE ob.id_contrato = co.id_contrato), ','::text)   AS objetos,
       ga.id_imovel,
       co.id_usuario_cadastro,
       co.ultima_modificacao,
       co.data_cadastro,
       co.id_contrato                                                             AS id_imovel_contrato
FROM m_contrato co
         LEFT JOIN d_contrato_garantia ga ON ga.id_contrato = co.id_contrato AND ga.id_imovel IS NOT NULL
WHERE ga.id_imovel IS NOT NULL
UNION
SELECT CASE
           WHEN co.fase_contrato::text = 'T'::text THEN 'T'::text
           WHEN co.cancelado = 'T'::bpchar THEN 'I'::text
           WHEN co.fase_contrato::text = 'R'::text THEN 'R'::text
           WHEN co.fase_contrato::text = 'C'::text THEN 'CO'::text
           WHEN co.fim_vigencia_indeterminado = 'T'::bpchar THEN 'A'::text
           WHEN co.data_fim_vigencia IS NULL THEN 'A'::text
           WHEN date_part('day'::text, co.data_fim_vigencia::timestamp with time zone - CURRENT_TIMESTAMP) >=
                0::double precision THEN 'A'::text
           ELSE 'V'::text
           END                                                                    AS status_contrato,
       co.id_uo_beneficiada,
       co.id_contrato                                                             AS numero_contrato,
       co.id_tipo_contrato,
       co.data_inicio_vigencia,
       co.data_fim_vigencia,
       co.valor_contrato,
       co.valor_original,
       co.id_indice_reajuste,
       co.id_fornecedor                                                           AS id_adverso_principal,
       co.id_contrato,
       array_to_string(ARRAY(SELECT ga.garantia
                             FROM d_contrato_garantia ga
                             WHERE ga.id_contrato = co.id_contrato), ','::text)   AS garantias,
       array_to_string(ARRAY(SELECT lto.tipo_objeto_contrato
                             FROM d_contrato_objeto ob_1
                                      JOIN lt_tipo_objeto_contrato lto
                                           ON ob_1.id_tipo_objeto_contrato = lto.id_tipo_objeto_contrato
                             WHERE ob_1.id_contrato = co.id_contrato), ','::text) AS objetos,
       ob.id_imovel,
       co.id_usuario_cadastro,
       co.ultima_modificacao,
       co.data_cadastro,
       co.id_contrato                                                             AS id_imovel_contrato
FROM m_contrato co
         LEFT JOIN d_contrato_objeto ob ON ob.id_contrato = co.id_contrato AND ob.id_imovel IS NOT NULL
WHERE ob.id_imovel IS NOT NULL
ORDER BY 11;

alter table d_imovel_contrato
    owner to postgres;

