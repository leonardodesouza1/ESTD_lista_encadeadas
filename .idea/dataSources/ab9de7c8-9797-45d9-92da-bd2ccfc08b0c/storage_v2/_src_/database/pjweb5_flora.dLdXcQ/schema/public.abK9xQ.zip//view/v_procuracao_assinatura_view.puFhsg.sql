create view v_procuracao_assinatura_view
            (fase_status, status_vencimento, numero_assinatura_sort, numero_assinatura, titulo, vencimento,
             id_unidade_organizacional, id_responsavel, id_gestao_assinatura, id_procuracao, data_cadastro,
             ultima_modificacao, id_usuario_cadastro)
as
SELECT CASE
           WHEN m_gestao_assinatura.fase::text = 'D'::text THEN 'D'::text
           WHEN m_gestao_assinatura.fase::text = 'A'::text THEN 'A'::text
           WHEN m_gestao_assinatura.fase::text = 'S'::text THEN 'S'::text
           WHEN m_gestao_assinatura.fase::text = 'F'::text THEN 'F'::text
           WHEN m_gestao_assinatura.fase::text = 'N'::text THEN 'N'::text
           WHEN m_gestao_assinatura.fase::text = 'E'::text THEN 'E'::text
           ELSE ''::text
           END                                                                                AS fase_status,
       CASE
           WHEN date_trunc('day'::text, m_gestao_assinatura.vencimento) < date_trunc('day'::text, CURRENT_TIMESTAMP) AND
                m_gestao_assinatura.fase::text <> 'F'::text THEN 'V'::text
           WHEN date_part('day'::text, m_gestao_assinatura.vencimento::timestamp with time zone - CURRENT_TIMESTAMP) <
                m_gestao_assinatura.dias_antecedencia_email::double precision AND m_gestao_assinatura.fase::text <> 'F'::text
               THEN 'A'::text
           WHEN m_gestao_assinatura.vencimento > CURRENT_TIMESTAMP AND m_gestao_assinatura.fase::text <> 'F'::text
               THEN 'P'::text
           WHEN m_gestao_assinatura.vencimento <= CURRENT_TIMESTAMP AND m_gestao_assinatura.fase::text <> 'F'::text
               THEN 'A'::text
           WHEN m_gestao_assinatura.fase::text = 'F'::text THEN 'F'::text
           ELSE NULL::text
           END                                                                                AS status_vencimento,
       0::numeric + to_number(m_gestao_assinatura.numero_assinatura::text, '999999999'::text) AS numero_assinatura_sort,
       m_gestao_assinatura.numero_assinatura,
       m_gestao_assinatura.titulo,
       m_gestao_assinatura.vencimento,
       m_gestao_assinatura.id_unidade_organizacional,
       m_gestao_assinatura.id_responsavel,
       m_gestao_assinatura.id_gestao_assinatura,
       m_gestao_assinatura.id_procuracao,
       m_gestao_assinatura.data_cadastro,
       m_gestao_assinatura.ultima_modificacao,
       m_gestao_assinatura.id_usuario_cadastro
FROM m_gestao_assinatura
WHERE m_gestao_assinatura.context_key_integracao::text = 'PC'::text
   OR m_gestao_assinatura.context_key_integracao::text = 'DC'::text;

alter table v_procuracao_assinatura_view
    owner to postgres;

