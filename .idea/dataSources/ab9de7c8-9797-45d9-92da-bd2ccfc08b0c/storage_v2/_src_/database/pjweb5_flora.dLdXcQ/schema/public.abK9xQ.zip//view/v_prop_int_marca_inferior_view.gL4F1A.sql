create view v_prop_int_marca_inferior_view
            (id_propriedade_intelectual, id_prop_int_marc_inferior_view, nome, codigo, id_titular, data_deposito,
             id_uo_beneficiada, id_marca_superior, data_cadastro, id_usuario_cadastro, ultima_modificacao, status)
as
SELECT marca_superior.id_propriedade_intelectual,
       marca_inferior.id_propriedade_intelectual AS id_prop_int_marc_inferior_view,
       marca_inferior.nome,
       marca_inferior.codigo,
       marca_inferior.id_titular,
       marca_inferior.data_deposito,
       marca_inferior.id_uo_beneficiada,
       marca_inferior.id_marca_superior,
       marca_superior.data_cadastro,
       marca_superior.id_usuario_cadastro,
       marca_superior.ultima_modificacao,
       CASE
           WHEN marca_inferior.situacao::text = 'E'::text THEN 'E'::text
           WHEN marca_inferior.situacao::text = 'R'::text THEN 'R'::text
           WHEN marca_inferior.situacao::text = 'X'::text THEN 'X'::text
           WHEN marca_inferior.situacao::text = 'A'::text THEN 'A'::text
           ELSE 'I'::text
           END                                   AS status
FROM m_propriedade_intelectual marca_superior
         JOIN m_propriedade_intelectual marca_inferior
              ON marca_inferior.id_marca_superior = marca_superior.id_propriedade_intelectual
WHERE marca_inferior.id_marca_superior = marca_superior.id_propriedade_intelectual;

alter table v_prop_int_marca_inferior_view
    owner to postgres;

