create view v_certidao_requisicao
            (fase, numero_requisicao, id_requisicao, titulo_requisicao, id_certidao, id_certidao_requisicao,
             data_cadastro, ultima_modificacao, id_usuario_cadastro, em_renovacao)
as
SELECT m_requisicao.fase,
       m_requisicao.numero_requisicao,
       m_requisicao.id_requisicao,
       m_requisicao.titulo                                   AS titulo_requisicao,
       m_requisicao.id_certidao,
       row_number() OVER (ORDER BY m_requisicao.id_certidao) AS id_certidao_requisicao,
       m_requisicao.data_cadastro,
       m_requisicao.ultima_modificacao,
       m_requisicao.id_usuario_cadastro,
       m_requisicao.em_renovacao
FROM m_requisicao
WHERE m_requisicao.id_certidao IS NOT NULL;

alter table v_certidao_requisicao
    owner to postgres;

