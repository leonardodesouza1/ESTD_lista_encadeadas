create function createinterval(i numeric) returns interval
    language plpgsql
as
$$
BEGIN
	       			 				RETURN cast(cast(i as varchar) || '  days' as INTERVAL);
	   			 				END;

$$;

alter function createinterval(numeric) owner to postgres;

