create view v_contrato_req_atributo_view
            (id_atributo, valor_atributo_requisicao, id_contrato, ordem_atributo_lt, id_contrato_req_atributo_view,
             data_cadastro, ultima_modificacao, id_usuario_cadastro)
as
SELECT reqat.id_atributo,
       reqat.valor_atributo_requisicao,
       co.id_contrato,
       tip.ordem                    AS ordem_atributo_lt,
       reqat.id_requisicao_atributo AS id_contrato_req_atributo_view,
       reqat.data_cadastro,
       reqat.ultima_modificacao,
       reqat.id_usuario_cadastro
FROM d_requisicao_atributo reqat
         JOIN m_requisicao req ON reqat.id_requisicao = req.id_requisicao
         JOIN m_contrato co ON co.id_requisicao = req.id_requisicao
         JOIN d_tipo_requisicao_atributo tip
              ON req.id_tipo_requisicao = tip.id_tipo_requisicao AND tip.id_atributo = reqat.id_atributo;

alter table v_contrato_req_atributo_view
    owner to postgres;

