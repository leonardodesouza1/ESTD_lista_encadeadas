create view v_processo_requisicao_integracao
            (status_view, fase, status_vencimento_view, numero_requisicao, titulo, id_tipo_requisicao,
             id_unidade_organizacional, data_cadastro, data_cadastro_requisicao, id_usuario_cadastro, id_requisicao,
             id_processo, data_historico, ultima_modificacao, id_usuario_responsavel, proximo_vencimento)
as
SELECT CASE
           WHEN req.fase::text = 'Q'::text THEN 'Q'::text
           WHEN req.fase::text = 'A'::text THEN 'A'::text
           WHEN req.fase::text = 'E'::text THEN 'E'::text
           WHEN req.fase::text = 'R'::text THEN 'R'::text
           WHEN req.fase::text = 'X'::text THEN 'X'::text
           WHEN req.fase::text = 'Z'::text THEN 'Z'::text
           WHEN req.fase::text = 'C'::text THEN 'C'::text
           WHEN req.fase::text = 'I'::text THEN 'I'::text
           ELSE ''::text
           END                    AS status_view,
       req.fase,
       CASE
           WHEN req.fase::text = 'A'::text AND req.vencimento_aprovacao IS NOT NULL THEN
               CASE
                   WHEN date_part('day'::text, req.vencimento_aprovacao::timestamp with time zone - now()) <
                        0::double precision THEN 'A'::text
                   WHEN date_part('day'::text, req.vencimento_aprovacao::timestamp with time zone - now()) <=
                        (((SELECT m_config_sistema.valor_config_sistema
                           FROM m_config_sistema
                           WHERE m_config_sistema.nome_config_sistema::text =
                                 'DIAS_N_UTEIS_PROX_VENC'::text))::double precision) THEN 'P'::text
                   ELSE 'D'::text
                   END
           WHEN req.fase::text = 'E'::text AND req.vencimento_execucao IS NOT NULL THEN
               CASE
                   WHEN date_part('day'::text, req.vencimento_execucao::timestamp with time zone - now()) <
                        0::double precision THEN 'A'::text
                   WHEN date_part('day'::text, req.vencimento_execucao::timestamp with time zone - now()) <=
                        (((SELECT m_config_sistema.valor_config_sistema
                           FROM m_config_sistema
                           WHERE m_config_sistema.nome_config_sistema::text =
                                 'DIAS_N_UTEIS_PROX_VENC'::text))::double precision) THEN 'P'::text
                   ELSE 'D'::text
                   END
           ELSE 'N'::text
           END                    AS status_vencimento_view,
       req.numero_requisicao,
       req.titulo,
       req.id_tipo_requisicao,
       req.id_unidade_organizacional,
       req.data_cadastro,
       req.data_cadastro          AS data_cadastro_requisicao,
       req.id_usuario_cadastro,
       req.id_requisicao,
       req.id_processo_requisicao AS id_processo,
       hist.data_historico,
       req.ultima_modificacao,
       req.id_usuario_responsavel,
       CASE
           WHEN req.fase::text = 'A'::text AND req.vencimento_aprovacao IS NOT NULL THEN req.vencimento_aprovacao
           WHEN req.fase::text = 'E'::text AND req.vencimento_execucao IS NOT NULL THEN req.vencimento_execucao
           WHEN req.fase::text = 'I'::text AND req.vencimento_informacao IS NOT NULL THEN req.vencimento_informacao
           ELSE NULL::timestamp without time zone
           END                    AS proximo_vencimento
FROM m_requisicao req
         JOIN d_historico_requisicao hist ON hist.id_requisicao = req.id_requisicao
WHERE hist.atual = 'T'::bpchar;

alter table v_processo_requisicao_integracao
    owner to postgres;

