create view v_val_atual_anterior_prov
            (atualizado_atual, atualizado_anterior, id_processo, data_calculo_anterior, data_calculo_atual) as
SELECT (SELECT sum(COALESCE(provisao_objeto_atual.valor_perda_provavel_atualizad, 0::numeric)) AS sum
        FROM d_provisao_processo
                 JOIN d_provisao_objeto_processo provisao_objeto_atual
                      ON d_provisao_processo.id_provisao_processo = provisao_objeto_atual.id_provisao_processo
        WHERE atual.data_calculo = d_provisao_processo.data_calculo
          AND provisao_processo.id_processo = d_provisao_processo.id_processo
        GROUP BY d_provisao_processo.id_processo) AS atualizado_atual,
       (SELECT sum(COALESCE(provisao_objeto_anterior.valor_perda_provavel_atualizad, 0::numeric)) AS sum
        FROM d_provisao_processo
                 JOIN d_provisao_objeto_processo provisao_objeto_anterior
                      ON d_provisao_processo.id_provisao_processo = provisao_objeto_anterior.id_provisao_processo
        WHERE anterior.data_calculo = d_provisao_processo.data_calculo
          AND provisao_processo.id_processo = d_provisao_processo.id_processo
        GROUP BY d_provisao_processo.id_processo) AS atualizado_anterior,
       provisao_processo.id_processo,
       anterior.data_calculo                      AS data_calculo_anterior,
       atual.data_calculo                         AS data_calculo_atual
FROM v_data_calculo_prov atual
         JOIN v_data_calculo_prov anterior ON anterior.linha = (atual.linha - 1)
         JOIN d_provisao_processo provisao_processo ON atual.data_calculo = provisao_processo.data_calculo;

alter table v_val_atual_anterior_prov
    owner to postgres;

