create view d_requisicao_procon
            (status_view, status_vencimento_view, numero_requisicao, titulo, id_tipo_requisicao,
             id_unidade_organizacional, data_cadastro, id_usuario_cadastro, id_requisicao, id_procon, data_historico,
             ultima_modificacao, id_usuario_responsavel)
as
SELECT CASE
           WHEN req.fase::text = 'Q'::text THEN 'Q'::text
           WHEN req.fase::text = 'A'::text THEN 'A'::text
           WHEN req.fase::text = 'E'::text THEN 'E'::text
           WHEN req.fase::text = 'R'::text THEN 'R'::text
           WHEN req.fase::text = 'X'::text THEN 'X'::text
           WHEN req.fase::text = 'Z'::text THEN 'Z'::text
           WHEN req.fase::text = 'C'::text THEN 'C'::text
           WHEN req.fase::text = 'I'::text THEN 'I'::text
           ELSE ''::text
           END AS status_view,
       CASE
           WHEN req.fase::text = 'A'::text AND req.vencimento_aprovacao IS NOT NULL THEN
               CASE
                   WHEN date_part('day'::text, req.vencimento_aprovacao::timestamp with time zone - CURRENT_TIMESTAMP) <
                        0::double precision THEN 'A'::text
                   WHEN date_part('day'::text,
                                  req.vencimento_aprovacao::timestamp with time zone - CURRENT_TIMESTAMP) <=
                        (((SELECT m_config_sistema.valor_config_sistema
                           FROM m_config_sistema
                           WHERE m_config_sistema.nome_config_sistema::text =
                                 'DIAS_N_UTEIS_PROX_VENC'::text))::double precision) THEN 'P'::text
                   ELSE 'D'::text
                   END
           WHEN req.fase::text = 'E'::text AND req.vencimento_execucao IS NOT NULL THEN
               CASE
                   WHEN date_part('day'::text, req.vencimento_execucao::timestamp with time zone - CURRENT_TIMESTAMP) <
                        0::double precision THEN 'A'::text
                   WHEN date_part('day'::text, req.vencimento_execucao::timestamp with time zone - CURRENT_TIMESTAMP) <=
                        (((SELECT m_config_sistema.valor_config_sistema
                           FROM m_config_sistema
                           WHERE m_config_sistema.nome_config_sistema::text =
                                 'DIAS_N_UTEIS_PROX_VENC'::text))::double precision) THEN 'P'::text
                   ELSE 'D'::text
                   END
           ELSE 'N'::text
           END AS status_vencimento_view,
       req.numero_requisicao,
       req.titulo,
       req.id_tipo_requisicao,
       req.id_unidade_organizacional,
       req.data_cadastro,
       req.id_usuario_cadastro,
       req.id_requisicao,
       req.id_procon,
       hist.data_historico,
       req.ultima_modificacao,
       req.id_usuario_responsavel
FROM m_requisicao req
         JOIN d_historico_requisicao hist ON hist.id_requisicao = req.id_requisicao
WHERE hist.atual = 'T'::bpchar;

alter table d_requisicao_procon
    owner to postgres;

