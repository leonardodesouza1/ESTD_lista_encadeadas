create function upper(i bigint) returns character varying
    language plpgsql
as
$$
BEGIN
            					RETURN upper(cast(i as varchar));
         					END;

$$;

alter function upper(bigint) owner to postgres;

