create view v_sum_valores_provisao_objeto
            (sum_correcao_monetaria_pedido, sum_valor_pedido, sum_multa_pedido, sum_perda_possivel, sum_perda_provavel,
             sum_juros_inicial_pedido, sum_juros_inicial_provavel, sum_juros_inicial_possivel, sum_multa_isolada_pedido,
             sum_multa_isolada_possivel, sum_multa_isolada_provavel, sum_taxa_pedido, sum_valor_pedido_atualiz,
             sum_perda_provavel_atualiz, sum_perda_possivel_atualiz, sum_valor_quitacao, sum_juros_possivel,
             sum_taxa_provavel, sum_taxa_possivel, sum_corr_monetario_provavel, sum_corr_monetario_pedido,
             sum_corr_monetario_possivel, sum_juros_pedido, sum_juros_provavel, sum_multa_possivel, sum_multa_provavel,
             id_provisao_processo, valor_base_honorario)
as
SELECT COALESCE(sum(provisao_objeto.correcao_monetaria_pedido), 0.00)      AS sum_correcao_monetaria_pedido,
       COALESCE(sum(provisao_objeto.valor_pedido), 0.00)                   AS sum_valor_pedido,
       COALESCE(sum(provisao_objeto.multa_pedido), 0.00)                   AS sum_multa_pedido,
       COALESCE(sum(provisao_objeto.valor_perda_possivel), 0.00)           AS sum_perda_possivel,
       COALESCE(sum(provisao_objeto.valor_perda_provavel), 0.00)           AS sum_perda_provavel,
       COALESCE(sum(provisao_objeto.juros_inicial_pedido), 0.00)           AS sum_juros_inicial_pedido,
       COALESCE(sum(provisao_objeto.juros_inicial_provavel), 0.00)         AS sum_juros_inicial_provavel,
       COALESCE(sum(provisao_objeto.juros_inicial_possivel), 0.00)         AS sum_juros_inicial_possivel,
       COALESCE(sum(provisao_objeto.multa_isolada_pedido), 0.00)           AS sum_multa_isolada_pedido,
       COALESCE(sum(provisao_objeto.multa_isolada_possivel), 0.00)         AS sum_multa_isolada_possivel,
       COALESCE(sum(provisao_objeto.multa_isolada_provavel), 0.00)         AS sum_multa_isolada_provavel,
       COALESCE(sum(provisao_objeto.taxa_pedido), 0.00)                    AS sum_taxa_pedido,
       COALESCE(sum(provisao_objeto.valor_pedido_atualizado), 0.00)        AS sum_valor_pedido_atualiz,
       COALESCE(sum(provisao_objeto.valor_perda_provavel_atualizad), 0.00) AS sum_perda_provavel_atualiz,
       COALESCE(sum(provisao_objeto.valor_perda_possivel_atualizad), 0.00) AS sum_perda_possivel_atualiz,
       COALESCE(sum(provisao_objeto.valor_quitacao), 0.00)                 AS sum_valor_quitacao,
       COALESCE(sum(provisao_objeto.juros_possivel), 0.00)                 AS sum_juros_possivel,
       COALESCE(sum(provisao_objeto.taxa_provavel), 0.00)                  AS sum_taxa_provavel,
       COALESCE(sum(provisao_objeto.taxa_possivel), 0.00)                  AS sum_taxa_possivel,
       COALESCE(sum(provisao_objeto.correcao_monetaria_provavel), 0.00)    AS sum_corr_monetario_provavel,
       COALESCE(sum(provisao_objeto.correcao_monetaria_pedido), 0.00)      AS sum_corr_monetario_pedido,
       COALESCE(sum(provisao_objeto.correcao_monetaria_possivel), 0.00)    AS sum_corr_monetario_possivel,
       COALESCE(sum(provisao_objeto.juros_pedido), 0.00)                   AS sum_juros_pedido,
       COALESCE(sum(provisao_objeto.juros_provavel), 0.00)                 AS sum_juros_provavel,
       COALESCE(sum(provisao_objeto.multa_possivel), 0.00)                 AS sum_multa_possivel,
       COALESCE(sum(provisao_objeto.multa_provavel), 0.00)                 AS sum_multa_provavel,
       provisao_objeto.id_provisao_processo,
       CASE
           WHEN (COALESCE(sum(provisao_objeto.valor_pedido_atualizado), 0::numeric) -
                 COALESCE(sum(provisao_objeto.valor_perda_provavel_atualizad), 0::numeric) -
                 COALESCE(sum(provisao_objeto.valor_perda_possivel_atualizad), 0::numeric)) > 0::numeric THEN
                   COALESCE(sum(provisao_objeto.valor_pedido_atualizado), 0.00) -
                   COALESCE(sum(provisao_objeto.valor_perda_provavel_atualizad), 0.00) -
                   COALESCE(sum(provisao_objeto.valor_perda_possivel_atualizad), 0.00)
           ELSE COALESCE(sum(provisao_objeto.valor_perda_possivel_atualizad), 0.00)
           END                                                             AS valor_base_honorario
FROM d_provisao_objeto_processo provisao_objeto
GROUP BY provisao_objeto.id_provisao_processo;

alter table v_sum_valores_provisao_objeto
    owner to postgres;

