create view v_data_calculo_prov(linha, data_calculo) as
SELECT row_number() OVER (ORDER BY d_provisao_processo.data_calculo) AS linha,
       d_provisao_processo.data_calculo
FROM d_provisao_processo
GROUP BY d_provisao_processo.data_calculo;

alter table v_data_calculo_prov
    owner to postgres;

