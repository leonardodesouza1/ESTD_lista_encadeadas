create function upper(i timestamp without time zone) returns character varying
    language plpgsql
as
$$
BEGIN
            					RETURN upper(cast(i as varchar));
         					END;

$$;

alter function upper(timestamp) owner to postgres;

