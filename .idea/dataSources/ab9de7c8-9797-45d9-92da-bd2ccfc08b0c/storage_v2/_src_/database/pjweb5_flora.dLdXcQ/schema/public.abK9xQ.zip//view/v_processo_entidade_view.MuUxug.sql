create view v_processo_entidade_view
            (status_processo, id_processo, numero_desdobramento_atual, id_natureza, empresa_principal, id_entidade,
             data_cadastro, id_usuario_cadastro, ultima_modificacao)
as
SELECT DISTINCT (SELECT CASE
                            WHEN m_processo.data_cadastro IS NULL AND m_processo.data_pre_cadastro IS NOT NULL AND
                                 m_processo.data_encerramento IS NULL THEN 'P'::text
                            WHEN m_processo.data_cadastro IS NOT NULL AND m_processo.data_encerramento IS NULL THEN 'A'::text
                            WHEN m_processo.data_encerramento IS NOT NULL THEN 'E'::text
                            ELSE ''::text
                            END AS "case"
                 FROM m_processo
                 WHERE m_processo.id_processo = pr.id_processo) AS status_processo,
                pr.id_processo,
                pr.numero_desdobramento_atual,
                (SELECT lt_natureza.id_natureza
                 FROM m_processo p
                          JOIN lt_natureza ON lt_natureza.id_natureza = p.id_natureza
                 WHERE p.id_processo = pr.id_processo)          AS id_natureza,
                (SELECT en.id_entidade
                 FROM m_processo p
                          LEFT JOIN d_processo_parte pa
                                    ON pa.id_processo = p.id_processo AND pa.cliente = 'T'::bpchar AND
                                       pa.principal = 'T'::bpchar
                          LEFT JOIN m_entidade en ON en.id_entidade = pa.id_entidade
                 WHERE p.id_processo = pr.id_processo)          AS empresa_principal,
                e.id_entidade,
                pr.data_cadastro,
                pr.id_usuario_cadastro,
                pr.ultima_modificacao
FROM m_processo pr
         LEFT JOIN d_processo_parte d
                   ON d.id_processo = pr.id_processo AND d.condicao::text = 'A'::text AND d.cliente = 'F'::bpchar
         LEFT JOIN mm_processo_advogado_adverso adv ON adv.id_processo = pr.id_processo
         JOIN m_entidade e ON d.id_entidade = e.id_entidade AND e.adverso_entidade_contumaz::text = 'T'::text OR
                              e.id_entidade = adv.id_entidade AND e.advgado_entidade_contumaz::text = 'T'::text OR
                              pr.id_advogado_adverso = e.id_entidade AND
                              e.advgado_entidade_contumaz::text = 'T'::text OR
                              d.id_entidade = e.id_entidade AND e.id_entidade = adv.id_entidade AND
                              pr.id_advogado_adverso = e.id_entidade AND
                              e.advgado_entidade_contumaz::text = 'T'::text AND e.adverso_entidade_contumaz::text = 'T'::text
ORDER BY pr.id_processo;

alter table v_processo_entidade_view
    owner to postgres;

