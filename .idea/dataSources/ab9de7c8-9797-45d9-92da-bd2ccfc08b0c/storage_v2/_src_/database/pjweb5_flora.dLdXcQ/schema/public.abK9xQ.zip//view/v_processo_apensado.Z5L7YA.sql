create view v_processo_apensado
            (id_processo_apenso, id_processo, id_processo_apensado, data_cadastro, ultima_modificacao,
             id_usuario_cadastro, pasta_apensada, numero_processo_apensado, id_tipo_acao_apensado, id_p_apensado)
as
SELECT mm.id_processo_apenso,
       mm.id_processo_apensado       AS id_processo,
       mm.id_processo_apensado,
       mm.data_cadastro,
       mm.ultima_modificacao,
       mm.id_usuario_cadastro,
       pr.pasta                      AS pasta_apensada,
       pr.numero_desdobramento_atual AS numero_processo_apensado,
       pr.id_tipo_acao               AS id_tipo_acao_apensado,
       mm.id_processo                AS id_p_apensado
FROM mm_processo_apenso mm
         JOIN m_processo pr ON mm.id_processo = pr.id_processo;

alter table v_processo_apensado
    owner to postgres;

