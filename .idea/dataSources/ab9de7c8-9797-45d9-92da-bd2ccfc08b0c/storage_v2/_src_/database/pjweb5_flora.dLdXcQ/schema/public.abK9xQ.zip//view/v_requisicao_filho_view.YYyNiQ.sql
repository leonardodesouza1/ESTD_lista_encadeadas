create view v_requisicao_filho_view
            (suspensao_sla_search, numero_tarefa, status_tarefa, titulo, id_requisicao, id_requisicao_filha,
             data_cadastro, id_usuario_cadastro, numero_requisicao, ultima_modificacao, id_usuario_responsavel,
             id_requisitante, id_tipo_requisicao, id_unidade_organizacional, data_fim_solicitacao, prazo_resposta,
             historico)
as
SELECT CASE
           WHEN req.suspensao_sla_principal = 'F'::bpchar THEN 'F'::text
           WHEN req.suspensao_sla_principal = 'T'::bpchar THEN 'T'::text
           ELSE ''::text
           END                 AS suspensao_sla_search,
       req.numero_requisicao   AS numero_tarefa,
       req.fase                AS status_tarefa,
       req.titulo,
       req.id_requisicao_pai   AS id_requisicao,
       req.id_requisicao       AS id_requisicao_filha,
       req.data_cadastro,
       req.id_usuario_cadastro,
       req.numero_requisicao,
       req.ultima_modificacao,
       req.id_usuario_responsavel,
       req.id_requisitante,
       req.id_tipo_requisicao,
       req.id_unidade_organizacional,
       req.vencimento_execucao AS data_fim_solicitacao,
       req.prazo_resposta,
       req.instrucao           AS historico
FROM m_requisicao req;

alter table v_requisicao_filho_view
    owner to postgres;

