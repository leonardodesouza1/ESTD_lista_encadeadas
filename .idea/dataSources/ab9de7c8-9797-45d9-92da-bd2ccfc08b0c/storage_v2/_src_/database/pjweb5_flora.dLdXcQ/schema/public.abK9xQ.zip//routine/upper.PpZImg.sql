create function upper(i numeric) returns character varying
    language plpgsql
as
$$
BEGIN
            					RETURN upper(cast(i as varchar));
         					END;

$$;

alter function upper(numeric) owner to postgres;

